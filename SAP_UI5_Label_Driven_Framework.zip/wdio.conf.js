exports.config = {
  runner: "local",
  specs: ["./test/specs/**/*.js"],
  maxInstances: 1,
  capabilities: [{ browserName: "chrome" }],
  baseUrl:
    "https://flpnwc-sycbz50by7.dispatcher.ca1.hana.ondemand.com/sites/GMS-CA-IQA#Shell-home",
  logLevel: "info",
  bail: 0,
  waitforTimeout: 15000,
  framework: "mocha",
  reporters: ["spec"],
  mochaOpts: { ui: "bdd", timeout: 180000 },
  // services: [
  //   [
  //     "static-server",
  //     { folders: [{ mount: "/", path: "./mock-app" }], port: 3000 },
  //   ],
  // ],
};
