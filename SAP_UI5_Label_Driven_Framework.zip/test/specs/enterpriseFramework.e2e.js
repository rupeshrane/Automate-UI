const path = require("path");
const assert = require("assert");
const envConfig = require("../../config/env/qa.json");
const { runFlow } = require("../../framework/core/flowRunner");
const waitEngine = require("../../framework/core/waitEngine");

describe("Enterprise framework flow", () => {
  it("runs login + flow from Excel", async () => {
    // ✅ FIX: always use qa.json baseUrl (single source of truth)
    await browser.url(envConfig.baseUrl);

    const workbookPath = path.resolve(
      process.cwd(),
      "templates",
      "Enterprise_Framework_Input.xlsx",
    );
    // await waitEngine.waitForSAPUI();
    await runFlow(workbookPath);

    const success = await $("#successMessage");
    await success.waitForDisplayed({ timeout: 20000 });

    assert.equal(await success.getText(), "Submitted successfully");

    await browser.pause(5000);
  });
});
