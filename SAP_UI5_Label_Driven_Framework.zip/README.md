# Final Enterprise UI5 Framework

This package is an enterprise-style core WDIO framework designed so QA primarily updates:
- Excel workbook
- environment JSON

## Included
- Login sheet
- Flow sheet
- Environment sheet
- Selectors sheet
- Captures sheet
- Retry engine
- Wait engine
- Context manager
- Self-healing selector fallback
- Generic action engine
- Generic validation engine
- WDIO runner
- Local mock app for first verification

## Run
```bash
npm install
npm test
```

## Workbook
Use:
`templates/Enterprise_Framework_Input.xlsx`

## Supported controls/actions
- tile + click
- text/textarea + enter
- dropdown + select
- checkbox + check/uncheck
- button + click

## Supported validations
- visible
- selected
- valueEquals
- checked
- textVisible

## IQA onboarding
1. Copy `config/env/qa.example.json` to `config/env/qa.json`
2. Put your real IQA URL and credentials there
3. Update selector strategies in the `Selectors` sheet
4. Expand the control/action matrix only when a truly new control appears

## Honest note
This package is enterprise-structured and stable for supported controls, but no framework can be universally "zero-code forever" for every custom UI control. The goal is to minimize project-specific code changes as much as possible.


## Label-driven SAP UI5 resolution

This framework now prefers a label-driven resolver for form fields.

How it works:
- Excel provides the business label in the `Label` column.
- The engine scans visible SAP labels on the screen.
- It links the label to the target control using `for`, `aria-labelledby`, same-form-container search, and geometric proximity.
- It then acts on the resolved UI5 control based on `ControlType`.

Recommended Excel usage:
- `Label`: exact visible field label from SAP screen
- `ControlType`: text, textarea, dropdown, checkbox, button, tile
- Avoid adding XPath for new fields unless you are using it only as an emergency fallback.
