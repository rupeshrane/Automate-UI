class SelfHealEngine {
  static async heal(step) {
    const label = step.Label.toLowerCase();

    const elements = await $$("*");

    for (const el of elements) {
      const text = await el.getText().catch(() => "");
      if (text && text.toLowerCase().includes(label)) {
        return el;
      }
    }

    throw new Error(`Self-healing failed for "${step.Label}"`);
  }
}
module.exports = SelfHealEngine;
