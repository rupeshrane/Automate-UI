const SelectorEngine = require('../core/selectorEngine');
const VariableStore = require('../core/variableStore');
const RetryEngine = require('../core/retryEngine');
const waitEngine = require('../core/waitEngine');

class ActionEngine {
  static async waitForUI5Idle() {
    await browser.waitUntil(
      async () => {
        const busy = await $('.sapUiLocalBusyIndicator').isExisting().catch(() => false);
        const busy2 = await $('.sapUiBusy').isExisting().catch(() => false);
        return !busy && !busy2;
      },
      {
        timeout: 30000,
        interval: 500,
        timeoutMsg: 'SAP UI5 still busy',
      },
    );
  }

  static async detectControlType(el, fallbackType = '') {
    const tag = await el.getTagName().catch(() => '');
    const cls = (await el.getAttribute('class').catch(() => '')) || '';
    const role = (await el.getAttribute('role').catch(() => '')) || '';
    const inputType = ((await el.getAttribute('type').catch(() => '')) || '').toLowerCase();

    if (inputType === 'checkbox' || cls.includes('sapMCb')) return 'checkbox';
    if (cls.includes('sapMSlt') || cls.includes('sapMComboBox') || role === 'combobox' || tag === 'select') return 'dropdown';
    if (cls.includes('sapMBtn') || role === 'button' || tag === 'button') return 'button';
    if (tag === 'textarea' || cls.includes('sapMTextArea')) return 'textarea';
    if (tag === 'input' || cls.includes('sapMInputBaseInner') || cls.includes('sapMInput')) return 'text';
    return fallbackType;
  }

  static async getInteractiveElement(el, controlType) {
    if (!el) return el;

    if (controlType === 'text' || controlType === 'textarea') {
      const tag = await el.getTagName().catch(() => '');
      if (tag === 'input' || tag === 'textarea') return el;
      const child = await el.$('input, textarea');
      if (await child.isExisting().catch(() => false)) return child;
    }

    if (controlType === 'checkbox') {
      const tag = await el.getTagName().catch(() => '');
      if (tag === 'input') return el;
      const child = await el.$('input[type="checkbox"], [role="checkbox"]');
      if (await child.isExisting().catch(() => false)) return child;
    }

    return el;
  }

  static async perform(step, selectorRows) {
    const action = String(step.Action || '').trim().toLowerCase();
    let controlType = String(step.ControlType || '').trim().toLowerCase();
    const label = String(step.Label || '').trim();
    const value = String(VariableStore.resolve(step.Value) ?? '');

    await RetryEngine.retry(
      async () => {
        await this.waitForUI5Idle();
        await waitEngine.waitForStableUI();

        let el = await SelectorEngine.resolve(step, selectorRows);
        if (!el) throw new Error(`Element not resolved for "${label}"`);

        await el.waitForDisplayed({ timeout: 25000 });
        await el.scrollIntoView().catch(() => {});

        controlType = await this.detectControlType(el, controlType);
        const target = await this.getInteractiveElement(el, controlType);

        if (!target) {
          throw new Error(`Interactive target not found for "${label}"`);
        }

        if ((controlType === 'tile' || controlType === 'button') && action === 'click') {
          await target.click();
          return;
        }

        if (['text', 'textarea'].includes(controlType) && ['enter', 'set', 'type'].includes(action)) {
          await target.waitForEnabled({ timeout: 15000 }).catch(() => {});
          await target.click();
          await target.clearValue().catch(() => {});
          await target.setValue(value);
          return;
        }

        if (controlType === 'dropdown' && ['select', 'choose'].includes(action)) {
          await target.click();
          await browser.waitUntil(async () => (await $$('[role="option"], .sapMSelectListItem, li[role="option"]').length) > 0, {
            timeout: 15000,
            interval: 400,
            timeoutMsg: `Dropdown options not shown for "${label}"`,
          });

          const options = await $$('[role="option"], .sapMSelectListItem, li[role="option"]');
          for (const opt of options) {
            const txt = (await opt.getText().catch(() => '')).trim();
            if (txt === value.trim()) {
              await opt.click();
              return;
            }
          }
          throw new Error(`Dropdown value not found: ${value}`);
        }

        if (controlType === 'checkbox' && ['check', 'uncheck', 'set', 'select'].includes(action)) {
          const shouldBeChecked = ['true', 'yes', 'y', 'check', 'checked', 'select'].includes(value.toLowerCase()) || action === 'check';
          const actual = await target.isSelected().catch(async () => {
            const aria = await target.getAttribute('aria-checked').catch(() => null);
            return aria === 'true';
          });
          if (actual !== shouldBeChecked) await target.click();
          return;
        }

        throw new Error(`Unsupported action "${action}" for "${label}" with type "${controlType}"`);
      },
      30000,
      700,
      `Action failed for "${label}"`,
    );

    await waitEngine.waitForStableUI();
  }
}

module.exports = ActionEngine;
