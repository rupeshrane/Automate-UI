const WaitEngine = require("../core/waitEngine");

class LoginActions {
  static async perform(step, envConfig) {
    const role = String(step.Role || "")
      .trim()
      .toLowerCase();

    const loginType = String(step["Login Type"] || "")
      .trim()
      .toLowerCase();

    if (!["sso", "ias"].includes(loginType)) {
      throw new Error(`Unsupported login type: ${loginType}`);
    }

    const creds = envConfig.credentials?.[role];
    if (!creds) {
      throw new Error(`No credentials configured for role "${role}"`);
    }

    const username = creds.username || process.env.TEST_USERNAME;
    const password = creds.password || process.env.TEST_PASSWORD;

    if (!username || !password) {
      throw new Error(`Missing username/password for role "${role}"`);
    }

    // =========================
    // STEP 1: USERNAME
    // =========================
    const usernameEl = await $(
      '#username, input[type="email"], input[name="loginfmt"], input[name="identifier"], input[type="text"]',
    );

    await usernameEl.waitForExist({ timeout: 20000 });
    await usernameEl.waitForDisplayed({ timeout: 20000 });
    await usernameEl.waitForEnabled({ timeout: 20000 });

    await usernameEl.click();
    await usernameEl.clearValue().catch(() => {});
    await usernameEl.setValue(username);

    // =========================
    // STEP 2: NEXT
    // =========================
    const nextBtn = await $(
      '//button[normalize-space()="Next"] | //input[@value="Next"] | //*[@role="button" and normalize-space()="Next"]',
    );

    await nextBtn.waitForExist({ timeout: 20000 });
    await nextBtn.waitForDisplayed({ timeout: 20000 });

    await nextBtn.click();

    await browser.pause(1000);
    await WaitEngine.waitForStableUI();

    // =========================
    // STEP 3: PASSWORD
    // =========================
    await browser.waitUntil(
      async () => {
        return await $("#i0118")
          .isExisting()
          .catch(() => false);
      },
      {
        timeout: 20000,
        timeoutMsg: "Password field did not appear",
      },
    );

    const passwordEl = await $("#i0118");

    await passwordEl.waitForExist({ timeout: 20000 });
    await passwordEl.waitForDisplayed({ timeout: 20000 });
    await passwordEl.waitForEnabled({ timeout: 20000 });

    await passwordEl.click();
    await browser.pause(500);

    await passwordEl.clearValue().catch(() => {});

    // slow typing for reactive login field
    for (const char of password) {
      await passwordEl.addValue(char);
      await browser.pause(50);
    }

    const entered = await passwordEl.getValue().catch(() => "");
    if (!entered) {
      throw new Error("Password was not accepted by reactive login field");
    }

    // =========================
    // STEP 4: SIGN IN
    // =========================
    const signInBtn = await $(
      '//button[normalize-space()="Sign in"] | //input[@value="Sign in"] | //*[@role="button" and normalize-space()="Sign in"]',
    );

    await signInBtn.waitForExist({ timeout: 20000 });
    await signInBtn.waitForDisplayed({ timeout: 20000 });

    await signInBtn.click();

    await browser.pause(1000);
    await WaitEngine.waitForStableUI();

    // =========================
    // STEP 4.5: STAY SIGNED IN (YES/NO SCREEN)
    // =========================
    const staySignedInBtn = await $("#idSIButton9");

    if (await staySignedInBtn.isExisting().catch(() => false)) {
      await staySignedInBtn.waitForDisplayed({ timeout: 20000 });
      await staySignedInBtn.waitForClickable({ timeout: 20000 });

      await staySignedInBtn.click();

      await browser.pause(1500);
      await WaitEngine.waitForStableUI();
    }

    // =========================
    // STEP 5: LANDING PAGE
    // =========================
    const landingEl = await $(
      '//*[normalize-space(text())="Create Claim/Grievance"] | //*[@data-qa-type="tile"]//*[contains(normalize-space(.),"Create Claim/Grievance")]',
    );
    // await waitEngine.waitForSAPUI();
    await landingEl.waitForExist({ timeout: 30000 });
    await landingEl.waitForDisplayed({ timeout: 30000 });
  }
}

module.exports = LoginActions;
