const SelectorEngine = require('../core/selectorEngine');
const RetryEngine = require('../core/retryEngine');

class ValidationEngine {
  static async perform(step, selectorRows) {
    const validationType = String(step.ValidationType || '').trim();
    const validationValue = String(step.ValidationValue || '').trim();
    const controlType = String(step.ControlType || '').trim().toLowerCase();

    if (!validationType) return;

    await RetryEngine.retry(async () => {
      if (validationType === 'textVisible') {
        const el = await SelectorEngine.textVisible(validationValue);
        if (!(await el.isDisplayed().catch(() => false))) {
          throw new Error(`Text "${validationValue}" is not visible`);
        }
        return;
      }

      const target = await SelectorEngine.resolve(step, selectorRows);
      if (!target) throw new Error(`Validation target not found for "${step.Label}"`);
      await target.waitForDisplayed({ timeout: 10000 });

      const inputEl = ['text', 'textarea', 'dropdown'].includes(controlType)
        ? await target.$('input, textarea, select')
        : target;
      const effective = (await inputEl.isExisting().catch(() => false)) ? inputEl : target;

      if (validationType === 'selected' && controlType === 'dropdown') {
        const actual = (await effective.getValue().catch(() => '')) || (await target.getText().catch(() => ''));
        if (String(actual).trim() !== validationValue) {
          throw new Error(`Validation failed for "${step.Label}". Expected selected "${validationValue}", got "${actual}"`);
        }
        return;
      }

      if (validationType === 'valueEquals' && ['text', 'textarea'].includes(controlType)) {
        const actual = await effective.getValue();
        if (String(actual).trim() !== validationValue) {
          throw new Error(`Validation failed for "${step.Label}". Expected value "${validationValue}", got "${actual}"`);
        }
        return;
      }

      if (validationType === 'checked' && controlType === 'checkbox') {
        const actual = await target.isSelected().catch(async () => (await target.getAttribute('aria-checked')) === 'true');
        const expected = validationValue.toLowerCase() === 'true';
        if (actual !== expected) {
          throw new Error(`Validation failed for "${step.Label}". Expected checked "${expected}", got "${actual}"`);
        }
        return;
      }

      if (validationType === 'visible') {
        if (!(await target.isDisplayed())) throw new Error(`"${step.Label}" is not visible`);
      }
    }, 15000, 500, `Validation failed for "${step.Label}"`);
  }
}

module.exports = ValidationEngine;
