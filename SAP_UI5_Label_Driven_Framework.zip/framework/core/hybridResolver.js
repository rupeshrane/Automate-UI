const SelectorEngine = require("./selectorEngine");
const AutoDetectEngine = require("./autoDetectEngine");
const SelfHealEngine = require("../intelligence/selfHealEngine");
const RetryEngine = require("./retryEngine");

class HybridResolver {
  static async resolve(step, selectorRows = []) {
    return RetryEngine.retry(
      async () => {
        const label = String(step.Label || "").trim();
        const controlType = String(step.ControlType || "")
          .trim()
          .toLowerCase();

        // =========================
        // 1. FORMS → STRICT EXCEL ONLY
        // =========================
        const formTypes = ["text", "textarea", "dropdown", "checkbox"];

        if (formTypes.includes(controlType)) {
          const el = await SelectorEngine.resolve(step, selectorRows);

          if (el && (await el.isExisting())) {
            return el;
          }

          // NO auto-detect for forms
          return await SelfHealEngine.heal(step);
        }

        // =========================
        // 2. ACTION ELEMENTS → AUTO DETECT
        // =========================
        const el = await AutoDetectEngine.findByLabel(label);

        if (el) {
          const type = await AutoDetectEngine.detectActionElement(el);

          if (["tile", "button", "link"].includes(type)) {
            return el;
          }
        }

        // =========================
        // 3. LAST RESORT → SELF HEAL
        // =========================
        return await SelfHealEngine.heal(step);
      },
      12000,
      400,
      `Hybrid resolution failed for "${step.Label}"`,
    );
  }
}

module.exports = HybridResolver;
