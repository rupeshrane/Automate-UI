class waitEngine {
  static async waitForSAPUI() {
    await browser.waitUntil(
      async () => {
        const tiles = await $$(
          '[data-qa-type="tile"], .sapMGT, .sapUshellTile',
        );
        return tiles.length > 0;
      },
      {
        timeout: 90000,
        interval: 1500,
        timeoutMsg: "SAP UI tiles not loaded",
      },
    );

    await browser.pause(2000); // SAP rendering buffer
  }

  static async waitForStableUI() {
    await browser.waitUntil(
      async () => {
        const state = await browser.execute(() => document.readyState);
        const busy = await browser.execute(() => {
          return (
            window.document.querySelector(".sapUiLocalBusyIndicator") !== null
          );
        });

        return state === "complete" && !busy;
      },
      {
        timeout: 30000,
        interval: 1000,
        timeoutMsg: "SAP UI not stable",
      },
    );

    await browser.pause(1500);
  }
  static async waitForSAPReady() {
    await browser.waitUntil(
      async () => {
        const busy = await $(".sapUiLocalBusyIndicator")
          .isExisting()
          .catch(() => false);

        const loaders = await $$(".sapUiBusy, .sapUiLocalBusyIndicator");

        return !busy && loaders.length === 0;
      },
      {
        timeout: 30000,
        interval: 500,
        timeoutMsg: "SAP UI5 not stable",
      },
    );

    await browser.pause(800);
  }
}

module.exports = waitEngine;
