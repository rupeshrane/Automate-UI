const SmartSelectorEngine = require("./smartSelectorEngine");
const retryEngine = require("../core/retryEngine");
const waitEngine = require("../core/waitEngine");

class ZeroActionEngine {
  static async perform(step) {
    const action = String(step.Action || "").toLowerCase();
    const label = String(step.Label || "");
    const value = String(step.Value || "");

    await retryEngine.retry(async () => {
      await waitEngine.waitForStableUI().catch(() => {});

      let el = await SmartSelectorEngine.find(label);

      if (!el) {
        throw new Error(`Element not found for label: ${label}`);
      }

      await el.waitForDisplayed({ timeout: 10000 });
      await el.scrollIntoView();

      const type = await SmartSelectorEngine.detectType(el);

      // =========================
      // CLICK (BUTTON/TILE)
      // =========================
      if (action === "click") {
        await el.click();
        return;
      }

      // =========================
      // INPUT
      // =========================
      if (action === "enter") {
        await el.setValue(value);
        return;
      }

      // =========================
      // DROPDOWN (SAP SAFE)
      // =========================
      if (action === "select") {
        await el.click();
        await browser.pause(800);
        await waitEngine.waitForStableUI().catch(() => {});

        const option = await $(
          `//div[contains(@class,"sapMPopover")]//*[
            @role="option" or contains(@class,"sapMSelectListItem")
          ][contains(normalize-space(.),"${value}")]`,
        );

        await option.waitForDisplayed({ timeout: 15000 });
        await option.click();
        return;
      }

      throw new Error(`Unsupported action: ${action}`);
    });

    await waitEngine.waitForStableUI().catch(() => {});
  }
}

module.exports = ZeroActionEngine;
