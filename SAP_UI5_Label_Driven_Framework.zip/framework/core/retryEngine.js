class RetryEngine {
  static async retry(
    fn,
    timeout = 20000,
    interval = 500,
    message = "Retry failed after timeout",
  ) {
    const start = Date.now();
    let lastError;
    let attempt = 0;

    while (Date.now() - start < timeout) {
      attempt++;

      try {
        return await fn();
      } catch (err) {
        lastError = err;
        const msg = err?.message || "";

        // ❌ DO NOT RETRY CONFIG / LOGIC ERRORS
        if (
          msg.includes("Unsupported control type") ||
          msg.includes("Element not found for label")
        ) {
          throw err;
        }

        // 🔥 STALE ELEMENT
        if (msg.includes("stale element")) {
          await browser.pause(800);
        }

        // 🔥 UI DELAYS
        if (msg.includes("not displayed") || msg.includes("not found")) {
          await browser.pause(1200);
        }

        await browser.pause(interval + attempt * 50);
      }
    }

    throw new Error(
      `${message}${lastError ? ` | Root: ${lastError.message}` : ""}`,
    );
  }
}

module.exports = RetryEngine;
