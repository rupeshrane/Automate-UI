class AutoDetectEngine {
  static normalize(t) {
    return String(t || "")
      .toLowerCase()
      .replace(/\s+/g, " ")
      .trim();
  }

  // FIND ELEMENT BY VISIBLE TEXT
  static async findByLabel(label) {
    const elements = await $$("*");

    for (const el of elements) {
      const text = await el.getText().catch(() => "");
      const aria = await el.getAttribute("aria-label").catch(() => "");
      const title = await el.getAttribute("title").catch(() => "");

      const combined = `${text} ${aria} ${title}`;

      if (this.normalize(combined).includes(this.normalize(label))) {
        return el;
      }
    }

    return null;
  }

  // DETECT ONLY ACTION TYPES (NO FORMS)
  static async detectActionElement(el) {
    const tag = await el.getTagName().catch(() => "");
    const role = await el.getAttribute("role").catch(() => "");
    const className = await el.getAttribute("class").catch(() => "");

    // TILE
    if (className.includes("sapMGT") || className.includes("sapUshellTile")) {
      return "tile";
    }

    // BUTTON
    if (tag === "button" || role === "button") {
      return "button";
    }

    // LINK
    if (tag === "a" || role === "link") {
      return "link";
    }

    return "unknown";
  }
}

module.exports = AutoDetectEngine;
