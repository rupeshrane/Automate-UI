const RetryEngine = require('./retryEngine');
const SelfHealEngine = require('../intelligence/selfHealEngine');
const UI5LabelResolver = require('./ui5LabelResolver');

class SelectorEngine {
  static async waitForUI5Stable() {
    await browser.waitUntil(
      async () => {
        const busy1 = await $('.sapUiLocalBusyIndicator').isExisting().catch(() => false);
        const busy2 = await $('.sapUiBusy').isExisting().catch(() => false);
        const ready = await browser.execute(() => document.readyState === 'complete');
        return !busy1 && !busy2 && ready;
      },
      {
        timeout: 30000,
        interval: 500,
        timeoutMsg: 'SAP UI5 not stable',
      },
    );
  }

  static async isValidUI5Element(el) {
    if (!el) return false;
    const existing = await el.isExisting().catch(() => false);
    if (!existing) return false;

    const tag = await el.getTagName().catch(() => '');
    if (tag === 'body') return false;

    const cls = await el.getAttribute('class').catch(() => '');
    const role = await el.getAttribute('role').catch(() => '');
    return (
      cls.includes('sap') ||
      ['input', 'textarea', 'button', 'select'].includes(tag) ||
      ['button', 'combobox', 'checkbox', 'switch'].includes(role)
    );
  }

  static async resolve(step, selectorRows = []) {
    return RetryEngine.retry(
      async () => {
        await this.waitForUI5Stable();

        const fromLabelEngine = await this.labelDrivenResolve(step);
        if (fromLabelEngine && (await this.isValidUI5Element(fromLabelEngine))) {
          await fromLabelEngine.waitForDisplayed({ timeout: 15000 }).catch(() => {});
          return fromLabelEngine;
        }

        const fallback = await this.defaultResolve(step, selectorRows);
        if (fallback && (await this.isValidUI5Element(fallback))) {
          await fallback.waitForDisplayed({ timeout: 15000 }).catch(() => {});
          return fallback;
        }

        return await SelfHealEngine.heal(step);
      },
      20000,
      500,
      `Unable to resolve selector for "${step.Label}"`,
    );
  }

  static async labelDrivenResolve(step) {
    const metadata = await UI5LabelResolver.resolve(step);
    if (!metadata?.id) return null;
    const safeId = CSS.escape(metadata.id);
    return await $(`#${safeId}`);
  }

  static async defaultResolve(step, selectorRows = []) {
    const label = String(step.Label || '').trim();
    const controlType = String(step.ControlType || '').trim().toLowerCase();

    if (controlType === 'button') {
      return await $(`//*[@role="button" and normalize-space(.)="${label}"] | //button[normalize-space(.)="${label}"]`);
    }

    if (controlType === 'tile') {
      return await $(`//*[contains(@class,"sapMGT") and .//*[normalize-space(.)="${label}"]]`);
    }

    if (controlType === 'dropdown') {
      const ariaMatch = await $(`//*[@role="combobox" and (contains(@aria-label,"${label}") or contains(@title,"${label}"))]`);
      if (await ariaMatch.isExisting().catch(() => false)) return ariaMatch;
    }

    if (['text', 'textarea'].includes(controlType)) {
      const ariaMatch = await $(`//*[@aria-label="${label}"] | //*[@title="${label}"]`);
      if (await ariaMatch.isExisting().catch(() => false)) return ariaMatch;
    }

    if (Array.isArray(selectorRows) && selectorRows.length) {
      const row = selectorRows.find((r) => String(r.Label || '').trim().toLowerCase() === label.toLowerCase());
      if (row?.Selector) {
        return await $(row.Selector);
      }
    }

    return null;
  }

  static async textVisible(text) {
    const normalized = String(text || '').trim();
    return await $(`//*[contains(normalize-space(.),"${normalized}")]`);
  }

  static async ensureStable(el) {
    if (!el) return el;
    const valid = await this.isValidUI5Element(el);
    if (!valid) throw new Error('Invalid UI5 element resolved');
    await el.waitForDisplayed({ timeout: 15000 }).catch(() => {});
    await el.scrollIntoView().catch(() => {});
    return el;
  }
}

module.exports = SelectorEngine;
