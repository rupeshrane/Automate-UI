const path = require("path");
const { readWorkbook } = require("./excelReader");
const { loadEnvConfig } = require("./configLoader");
const Logger = require("../utils/logger");

const LoginActions = require("../actions/login.actions");
const ActionEngine = require("../actions/actionEngine");
const ValidationEngine = require("../validations/validationEngine");

class FlowEngine {
  static async run(workbookPath) {
    const envConfig = loadEnvConfig();
    const workbook = readWorkbook(
      workbookPath ||
        path.resolve(
          process.cwd(),
          "templates",
          "Enterprise_Framework_Input.xlsx",
        ),
    );

    await this.executeLogin(workbook.login, envConfig);
    await this.executeFlow(workbook.flow, workbook);
  }

  static async executeLogin(loginSheet, envConfig) {
    for (const step of loginSheet) {
      if (step.Action?.toLowerCase() === "login") {
        Logger.info(`LOGIN → Role: ${step.Role}`);
        await LoginActions.perform(step, envConfig);
      }
    }
  }

  static async executeFlow(flowSheet, workbook) {
    for (const step of flowSheet) {
      Logger.info(`STEP → ${step.Step}: ${step.Label}`);

      await ActionEngine.perform(step, workbook.selectors);
      await ValidationEngine.perform(step, workbook.selectors);
    }
  }
}

module.exports = FlowEngine;
