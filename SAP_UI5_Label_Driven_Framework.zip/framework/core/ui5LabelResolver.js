class UI5LabelResolver {
  static normalize(text) {
    return String(text || '')
      .toLowerCase()
      .replace(/[:*]+$/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  static async resolve(step) {
    const label = String(step.Label || '').trim();
    const controlType = String(step.ControlType || '').trim().toLowerCase();

    if (!label) return null;

    const metadata = await browser.execute(
      (rawLabel, rawControlType) => {
        const normalize = (text) =>
          String(text || '')
            .toLowerCase()
            .replace(/[:*]+$/g, '')
            .replace(/\s+/g, ' ')
            .trim();

        const isVisible = (el) => {
          if (!el || !(el instanceof Element)) return false;
          const style = window.getComputedStyle(el);
          const rect = el.getBoundingClientRect();
          return (
            style &&
            style.visibility !== 'hidden' &&
            style.display !== 'none' &&
            rect.width > 0 &&
            rect.height > 0
          );
        };

        const getText = (el) => {
          if (!el) return '';
          return (
            el.innerText ||
            el.textContent ||
            el.getAttribute('aria-label') ||
            el.getAttribute('title') ||
            el.value ||
            ''
          )
            .replace(/\s+/g, ' ')
            .trim();
        };

        const inferKind = (el) => {
          if (!el) return 'unknown';
          const cls = el.className?.baseVal || el.className || '';
          const tag = (el.tagName || '').toLowerCase();
          const role = el.getAttribute?.('role') || '';
          const type = (el.getAttribute?.('type') || '').toLowerCase();

          if (cls.includes('sapMGT')) return 'tile';
          if (cls.includes('sapMBtn') || tag === 'button' || role === 'button') return 'button';
          if (type === 'checkbox' || cls.includes('sapMCb')) return 'checkbox';
          if (cls.includes('sapMSwt')) return 'switch';
          if (cls.includes('sapMComboBox') || cls.includes('sapMSlt') || role === 'combobox' || tag === 'select') return 'dropdown';
          if (tag === 'textarea' || cls.includes('sapMTextArea')) return 'textarea';
          if (tag === 'input' || cls.includes('sapMInput') || cls.includes('sapMInputBaseInner')) return 'text';
          return 'unknown';
        };

        const requestedKind = (() => {
          if (['text', 'textarea', 'dropdown', 'checkbox', 'button', 'tile', 'switch'].includes(rawControlType)) return rawControlType;
          return 'unknown';
        })();

        const targetLabel = normalize(rawLabel);
        const controlSelectors = [
          'input',
          'textarea',
          'select',
          '[role="combobox"]',
          '[role="button"]',
          'button',
          '.sapMInputBaseInner',
          '.sapMTextAreaInner',
          '.sapMSlt',
          '.sapMComboBox',
          '.sapMCb',
          '.sapMSwt',
          '.sapMBtn',
          '.sapMGT',
        ];

        const candidateControls = Array.from(document.querySelectorAll(controlSelectors.join(',')))
          .filter(isVisible)
          .map((el) => {
            const rect = el.getBoundingClientRect();
            return {
              el,
              id: el.id || '',
              kind: inferKind(el),
              text: getText(el),
              aria: el.getAttribute('aria-label') || '',
              title: el.getAttribute('title') || '',
              rect,
              cls: el.className?.baseVal || el.className || '',
            };
          });

        const scoreKind = (kind) => {
          if (requestedKind === 'unknown') return 0;
          if (requestedKind === kind) return 8;
          if (requestedKind === 'text' && kind === 'textarea') return 4;
          if (requestedKind === 'textarea' && kind === 'text') return 2;
          if (requestedKind === 'button' && kind === 'tile') return 2;
          return -5;
        };

        const materialize = (control, reason, score) => {
          if (!control || !control.el) return null;
          return {
            id: control.el.id || '',
            kind: control.kind,
            text: control.text,
            aria: control.aria,
            cls: control.cls,
            reason,
            score,
          };
        };

        const byIdOrClosestInteractive = (node) => {
          if (!node) return null;
          if (candidateControls.some((c) => c.el === node)) {
            return candidateControls.find((c) => c.el === node) || null;
          }
          const nested = node.matches?.(controlSelectors.join(','))
            ? node
            : node.querySelector?.(controlSelectors.join(','));
          if (!nested) return null;
          return candidateControls.find((c) => c.el === nested) || null;
        };

        const resolveFromLabelNode = (labelNode) => {
          const results = [];
          const labelRect = labelNode.getBoundingClientRect();
          const labelId = labelNode.id || '';
          const htmlFor = labelNode.getAttribute('for') || labelNode.htmlFor || '';

          if (htmlFor) {
            const target = document.getElementById(htmlFor);
            const control = byIdOrClosestInteractive(target);
            if (control) results.push({ control, reason: 'for-association', score: 100 + scoreKind(control.kind) });
          }

          if (labelId) {
            const labelled = Array.from(document.querySelectorAll(`[aria-labelledby~="${labelId}"]`));
            for (const node of labelled) {
              const control = byIdOrClosestInteractive(node);
              if (control) results.push({ control, reason: 'aria-labelledby', score: 95 + scoreKind(control.kind) });
            }
          }

          const formContainer =
            labelNode.closest('.sapUiFormElement, .sapUiFormContainer, .sapUiRespGridSpanXL6, .sapUiRespGridSpanL6, .sapMFlexBox, .sapUiSimpleForm, .sapUiFormResGridCont, .sapMPanelContent') ||
            labelNode.parentElement;

          if (formContainer) {
            const nearby = Array.from(formContainer.querySelectorAll(controlSelectors.join(',')));
            for (const node of nearby) {
              const control = byIdOrClosestInteractive(node);
              if (!control) continue;
              const rect = control.rect;
              const distance = Math.abs(rect.top - labelRect.top) + Math.abs(rect.left - labelRect.right);
              let score = 70 - Math.min(distance / 10, 40) + scoreKind(control.kind);
              if (rect.left >= labelRect.left - 50) score += 8;
              if (Math.abs(rect.top - labelRect.top) < 60) score += 10;
              results.push({ control, reason: 'same-form-container', score });
            }
          }

          const geometric = candidateControls.map((control) => {
            const rect = control.rect;
            const vertical = Math.abs(rect.top - labelRect.top);
            const horizontal = rect.left - labelRect.right;
            const nearRight = horizontal >= -40 && horizontal < 500;
            const nearBelow = rect.top >= labelRect.bottom - 20 && rect.top < labelRect.bottom + 140;
            let score = 0;
            if (nearRight) score += 50;
            if (nearBelow) score += 30;
            score -= Math.min(vertical / 8, 25);
            score += scoreKind(control.kind);
            return { control, reason: 'geometric-nearby', score };
          });

          results.push(...geometric);

          results.sort((a, b) => b.score - a.score);
          return results[0] || null;
        };

        if (requestedKind === 'button' || requestedKind === 'tile') {
          const actionCandidates = candidateControls
            .filter((c) => ['button', 'tile'].includes(c.kind))
            .map((c) => {
              const combined = normalize(`${c.text} ${c.aria} ${c.title}`);
              let score = scoreKind(c.kind);
              if (combined === targetLabel) score += 100;
              else if (combined.includes(targetLabel)) score += 70;
              return { control: c, reason: 'action-text-match', score };
            })
            .sort((a, b) => b.score - a.score);

          return materialize(actionCandidates[0]?.control, actionCandidates[0]?.reason, actionCandidates[0]?.score || 0);
        }

        const labelNodes = Array.from(document.querySelectorAll('label, .sapMLabel, span, div'))
          .filter(isVisible)
          .map((el) => ({ el, text: normalize(getText(el)) }))
          .filter((x) => x.text && (x.text === targetLabel || x.text.includes(targetLabel) || targetLabel.includes(x.text)));

        const ranked = [];
        for (const { el, text } of labelNodes) {
          const association = resolveFromLabelNode(el);
          if (!association) continue;
          let score = association.score;
          if (text === targetLabel) score += 30;
          else score += 10;
          ranked.push({ ...association, score });
        }

        const ariaMatches = candidateControls
          .map((c) => {
            const combined = normalize(`${c.aria} ${c.title} ${c.text}`);
            let score = scoreKind(c.kind);
            if (combined === targetLabel) score += 80;
            else if (combined.includes(targetLabel)) score += 50;
            return { control: c, reason: 'direct-aria-text', score };
          })
          .filter((x) => x.score > 10);

        ranked.push(...ariaMatches);
        ranked.sort((a, b) => b.score - a.score);

        return materialize(ranked[0]?.control, ranked[0]?.reason, ranked[0]?.score || 0);
      },
      label,
      controlType,
    );

    if (!metadata || !metadata.id) return null;
    return metadata;
  }
}

module.exports = UI5LabelResolver;
