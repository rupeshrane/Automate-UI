const FlowEngine = require("./flowEngine");

async function runFlow(workbookPath) {
  return FlowEngine.run(workbookPath);
}

module.exports = { runFlow };
