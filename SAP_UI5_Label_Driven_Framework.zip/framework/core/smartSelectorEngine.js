class SmartSelectorEngine {
  static normalize(text) {
    return String(text || "")
      .toLowerCase()
      .replace(/\s+/g, " ")
      .trim();
  }

  static async find(label) {
    const elements = await $$(
      "button, div, input, span, a, [role='button'], [role='combobox'], [role='option']",
    );

    let best = null;
    let bestScore = 0;

    for (const el of elements) {
      const text = await el.getText().catch(() => "");
      const aria = await el.getAttribute("aria-label").catch(() => "");
      const title = await el.getAttribute("title").catch(() => "");

      const combined = `${text} ${aria} ${title}`;

      const normLabel = this.normalize(label);
      const normText = this.normalize(combined);

      let score = 0;

      if (normText === normLabel) score += 5;
      else if (normText.includes(normLabel)) score += 3;

      if (aria) score += 1;
      if (title) score += 1;

      if (score > bestScore) {
        best = el;
        bestScore = score;
      }
    }

    return best;
  }

  static async detectType(el) {
    const tag = await el.getTagName().catch(() => "");
    const role = await el.getAttribute("role").catch(() => "");
    const className = await el.getAttribute("class").catch(() => "");

    if (className.includes("sapMBtn") || role === "button") return "button";
    if (className.includes("sapMSlt") || role === "combobox") return "dropdown";
    if (className.includes("sapMInputBaseInner") || tag === "input")
      return "input";
    if (className.includes("sapMGT")) return "tile";

    return "unknown";
  }
}

module.exports = SmartSelectorEngine;
