const RetryEngine = require('./retryEngine');
const SelfHealEngine = require('../intelligence/selfHealEngine');

class SelectorEngine {
  static async resolve(step, selectorRows = []) {
    return RetryEngine.retry(async () => {
      const label = String(step.Label || '').trim();
      const controlType = String(step.ControlType || '').trim().toLowerCase();
      const moduleName = String(step.Module || '').trim();
      const page = String(step.Page || '').trim();
      const section = String(step.Section || '').trim();

      const mapping = selectorRows.find(r =>
        String(r.Module || '').trim() === moduleName &&
        String(r.Page || '').trim() === page &&
        String(r.Section || '').trim() === section &&
        String(r.Label || '').trim() === label &&
        String(r.ControlType || '').trim().toLowerCase() === controlType
      );

      let el = null;
      if (mapping) {
        el = await this.fromStrategy(mapping.PrimaryStrategy, mapping.PrimaryValue, step);
        try { if (el && await el.isExisting()) return el; } catch (e) {}

        el = await this.fromStrategy(mapping.SecondaryStrategy, mapping.SecondaryValue, step);
        try { if (el && await el.isExisting()) return el; } catch (e) {}
      }

      el = await this.defaultResolve(step);
      try { if (el && await el.isExisting()) return el; } catch (e) {}

      return await SelfHealEngine.heal(step);
    }, 12000, 400, `Unable to resolve selector for "${step.Label}"`);
  }

  static async fromStrategy(strategy, value, step) {
    const s = String(strategy || '').trim();
    const v = String(value || '').trim();
    if (!s) return null;

    if (s === 'tileText') return $(`//*[@data-qa-type="tile"]//*[normalize-space(text())="${v}"]/ancestor::*[@data-qa-type="tile"][1]`);
    if (s === 'buttonText') return $(`//button[normalize-space(.)="${v}"] | //*[@role="button" and normalize-space(.)="${v}"]`);
    if (s === 'fieldLabelAttr') {
      if (step.ControlType.toLowerCase() === 'dropdown') return $(`//*[@data-field-label="${v}"]//select`);
      if (step.ControlType.toLowerCase() === 'checkbox') return $(`//*[@data-field-label="${v}"]//input[@type="checkbox"]`);
      if (step.ControlType.toLowerCase() === 'button') return $(`//*[@data-field-label="${v}"]//button`);
      return $(`//*[@data-field-label="${v}"]//input[not(@type="checkbox")] | //*[@data-field-label="${v}"]//textarea`);
    }
    if (s === 'css') return $(v);
    if (s === 'xpath') return $(v);
    return null;
  }

  static async defaultResolve(step) {
    const label = String(step.Label || '').trim();
    const controlType = String(step.ControlType || '').trim().toLowerCase();

    if (controlType === 'tile') return $(`//*[normalize-space(text())="${label}"]/ancestor::*[@data-qa-type="tile"][1]`);
    if (controlType === 'button') return $(`//button[normalize-space(.)="${label}"] | //*[@role="button" and normalize-space(.)="${label}"]`);
    if (controlType === 'dropdown') return $(`//*[@data-field-label="${label}"]//select`);
    if (controlType === 'checkbox') return $(`//*[@data-field-label="${label}"]//input[@type="checkbox"]`);
    if (['text','textarea'].includes(controlType)) return $(`//*[@data-field-label="${label}"]//input[not(@type="checkbox")] | //*[@data-field-label="${label}"]//textarea`);

    throw new Error(`No default selector strategy available for control type "${controlType}" and label "${label}"`);
  }

  static async textVisible(text) {
    return $(`//*[normalize-space(text())="${text}"]`);
  }
}
module.exports = SelectorEngine;
