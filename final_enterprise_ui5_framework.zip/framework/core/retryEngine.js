class RetryEngine {
  static async retry(fn, timeout = 15000, interval = 500, message = 'Retry failed after timeout') {
    const start = Date.now();
    let lastError;
    while (Date.now() - start < timeout) {
      try {
        return await fn();
      } catch (err) {
        lastError = err;
        await browser.pause(interval);
      }
    }
    throw new Error(`${message}${lastError ? `: ${lastError.message}` : ''}`);
  }
}
module.exports = RetryEngine;
