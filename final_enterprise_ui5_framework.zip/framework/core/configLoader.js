const fs = require('fs');
const path = require('path');

function loadEnvConfig(envName = process.env.TEST_ENV || 'local') {
  const filePath = path.resolve(process.cwd(), 'config', 'env', `${envName}.json`);
  if (!fs.existsSync(filePath)) throw new Error(`Environment config not found: ${filePath}`);
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

module.exports = { loadEnvConfig };
