class WaitEngine {
  static async waitForStableUI() {
    await browser.waitUntil(async () => {
      try {
        return await browser.execute(() => document.readyState === 'complete');
      } catch (e) {
        return false;
      }
    }, { timeout: 10000, interval: 250 });
    await browser.pause(300);
  }
}
module.exports = WaitEngine;
