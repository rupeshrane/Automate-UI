class ContextManager {
  static currentModule = null;
  static currentPage = null;
  static currentSection = null;

  static set(step) {
    this.currentModule = step.Module || null;
    this.currentPage = step.Page || null;
    this.currentSection = step.Section || null;
  }

  static get() {
    return {
      module: this.currentModule,
      page: this.currentPage,
      section: this.currentSection
    };
  }
}
module.exports = ContextManager;
