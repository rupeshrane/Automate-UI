const xlsx = require('xlsx');

function readSheet(filePath, sheetName) {
  const wb = xlsx.readFile(filePath);
  const sheet = wb.Sheets[sheetName];
  if (!sheet) throw new Error(`Sheet "${sheetName}" not found in ${filePath}`);
  return xlsx.utils.sheet_to_json(sheet, { defval: '' });
}

function readWorkbook(filePath) {
  return {
    login: readSheet(filePath, 'Login'),
    flow: readSheet(filePath, 'Flow'),
    environment: readSheet(filePath, 'Environment'),
    selectors: readSheet(filePath, 'Selectors'),
    captures: readSheet(filePath, 'Captures')
  };
}

module.exports = { readSheet, readWorkbook };
