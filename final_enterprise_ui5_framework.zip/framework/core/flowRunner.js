const path = require('path');
const { readWorkbook } = require('./excelReader');
const { loadEnvConfig } = require('./configLoader');
const ContextManager = require('./contextManager');
const LoginActions = require('../actions/login.actions');
const ActionEngine = require('../actions/actionEngine');
const ValidationEngine = require('../validations/validationEngine');
const Logger = require('../utils/logger');

async function runFlow(workbookPath = path.resolve(process.cwd(), 'templates', 'Enterprise_Framework_Input.xlsx')) {
  const envConfig = loadEnvConfig();
  const workbook = readWorkbook(workbookPath);

  for (const step of workbook.login) {
    if (String(step.Action || '').trim().toLowerCase() === 'login') {
      Logger.info(`Executing login for role: ${step.Role}`);
      await LoginActions.perform(step, envConfig);
    }
  }

  for (const step of workbook.flow) {
    ContextManager.set(step);
    Logger.info(`Executing step ${step.Step}: ${step.Label}`);
    await ActionEngine.perform(step, workbook.selectors);
    await ValidationEngine.perform(step, workbook.selectors);
  }
}
module.exports = { runFlow };
