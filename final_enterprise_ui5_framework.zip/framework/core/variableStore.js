class VariableStore {
  static data = {};

  static set(key, value) { this.data[key] = value; }
  static get(key) { return this.data[key]; }

  static resolve(rawValue) {
    const value = String(rawValue ?? '');
    return value.replace(/\$\{([^}]+)\}/g, (_, key) => {
      const stored = this.get(key);
      return stored === undefined ? '' : String(stored);
    });
  }
}
module.exports = VariableStore;
