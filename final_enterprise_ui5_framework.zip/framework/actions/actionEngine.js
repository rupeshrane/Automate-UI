const SelectorEngine = require('../core/selectorEngine');
const VariableStore = require('../core/variableStore');
const RetryEngine = require('../core/retryEngine');
const WaitEngine = require('../core/waitEngine');

class ActionEngine {
  static async perform(step, selectorRows) {
    const action = String(step.Action || '').trim().toLowerCase();
    const controlType = String(step.ControlType || '').trim().toLowerCase();
    const label = String(step.Label || '').trim();
    const value = VariableStore.resolve(step.Value);

    await RetryEngine.retry(async () => {
      const el = await SelectorEngine.resolve(step, selectorRows);
      await el.waitForDisplayed({ timeout: 10000 });

      if (controlType === 'tile' && action === 'click') {
        await el.click();
        return;
      }

      if (['text', 'textarea'].includes(controlType) && action === 'enter') {
        await el.setValue(value);
        return;
      }

      if (controlType === 'dropdown' && action === 'select') {
        const options = await el.$$('option');
        const optionTexts = [];
        for (const option of options) {
          optionTexts.push((await option.getText()).trim());
        }
        if (!optionTexts.includes(value)) {
          throw new Error(`Value "${value}" not found in dropdown "${label}". Available: ${optionTexts.join(', ')}`);
        }
        await el.selectByVisibleText(value);
        return;
      }

      if (controlType === 'checkbox' && ['check', 'uncheck'].includes(action)) {
        const isChecked = await el.isSelected();
        const wantsChecked = action === 'check';
        if (wantsChecked !== isChecked) await el.click();
        return;
      }

      if (controlType === 'button' && action === 'click') {
        await el.click();
        return;
      }

      throw new Error(`Unsupported action "${action}" for control type "${controlType}" and label "${label}"`);
    }, 15000, 500, `Action failed for "${label}"`);

    await WaitEngine.waitForStableUI();
  }
}
module.exports = ActionEngine;
