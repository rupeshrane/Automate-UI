const WaitEngine = require('../core/waitEngine');

class LoginActions {
  static async perform(step, envConfig) {
    const role = String(step.Role || '').trim().toLowerCase();
    const loginType = String(step['Login Type'] || '').trim().toLowerCase();

    if (!['sso', 'ias'].includes(loginType)) {
      throw new Error(`Unsupported login type: ${loginType}`);
    }

    const creds = envConfig.credentials?.[role];
    if (!creds) throw new Error(`No credentials configured for role "${role}"`);

    const username = creds.username || process.env.TEST_USERNAME;
    const password = creds.password || process.env.TEST_PASSWORD;
    if (!username || !password) throw new Error(`Missing username/password for role "${role}"`);

    const usernameEl = await $('#username');
    const passwordEl = await $('#password');
    const loginBtn = await $('#loginButton');

    await usernameEl.waitForDisplayed({ timeout: 15000 });
    await usernameEl.setValue(username);
    await passwordEl.setValue(password);
    await loginBtn.click();

    await WaitEngine.waitForStableUI();

    const launchpad = await $('#launchpad');
    await launchpad.waitForDisplayed({ timeout: 15000 });
  }
}
module.exports = LoginActions;
