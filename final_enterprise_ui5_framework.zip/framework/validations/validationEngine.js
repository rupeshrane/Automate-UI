const SelectorEngine = require('../core/selectorEngine');
const RetryEngine = require('../core/retryEngine');

class ValidationEngine {
  static async perform(step, selectorRows) {
    const validationType = String(step.ValidationType || '').trim();
    const validationValue = String(step.ValidationValue || '').trim();
    const controlType = String(step.ControlType || '').trim().toLowerCase();

    if (!validationType) return;

    await RetryEngine.retry(async () => {
      if (validationType === 'textVisible') {
        const el = await SelectorEngine.textVisible(validationValue);
        if (!await el.isDisplayed()) throw new Error(`Text "${validationValue}" is not visible`);
        return;
      }

      const target = await SelectorEngine.resolve(step, selectorRows);
      await target.waitForDisplayed({ timeout: 10000 });

      if (validationType === 'selected' && controlType === 'dropdown') {
        const actual = await target.getValue();
        if (actual !== validationValue) {
          throw new Error(`Validation failed for "${step.Label}". Expected selected "${validationValue}", got "${actual}"`);
        }
        return;
      }

      if (validationType === 'valueEquals' && ['text', 'textarea'].includes(controlType)) {
        const actual = await target.getValue();
        if (actual !== validationValue) {
          throw new Error(`Validation failed for "${step.Label}". Expected value "${validationValue}", got "${actual}"`);
        }
        return;
      }

      if (validationType === 'checked' && controlType === 'checkbox') {
        const actual = await target.isSelected();
        const expected = validationValue.toLowerCase() === 'true';
        if (actual !== expected) {
          throw new Error(`Validation failed for "${step.Label}". Expected checked "${expected}", got "${actual}"`);
        }
        return;
      }

      if (validationType === 'visible') {
        if (!await target.isDisplayed()) throw new Error(`"${step.Label}" is not visible`);
      }
    }, 15000, 500, `Validation failed for "${step.Label}"`);
  }
}
module.exports = ValidationEngine;
