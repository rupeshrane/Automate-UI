class SelfHealEngine {
  static async heal(step) {
    const label = String(step.Label || '').trim();
    const candidates = [
      `//*[normalize-space(text())="${label}"]`,
      `//*[@placeholder="${label}"]`,
      `//*[@aria-label="${label}"]`,
      `//*[contains(normalize-space(text()), "${label}")]`
    ];

    for (const xpath of candidates) {
      const el = await $(xpath);
      try {
        if (await el.isExisting()) return el;
      } catch (e) {}
    }
    throw new Error(`Self-healing failed for "${label}"`);
  }
}
module.exports = SelfHealEngine;
