const path = require('path');
const assert = require('assert');
const { runFlow } = require('../../framework/core/flowRunner');

describe('Enterprise framework flow', () => {
  it('runs login + flow from Excel', async () => {
    await browser.url('/');
    const workbookPath = path.resolve(process.cwd(), 'templates', 'Enterprise_Framework_Input.xlsx');
    await runFlow(workbookPath);

    const success = await $('#successMessage');
    await success.waitForDisplayed({ timeout: 10000 });
    assert.equal(await success.getText(), 'Submitted successfully');

    await browser.pause(5000);
  });
});
